package common.scholastic.teams.entities;

public class Esc {

	private String descName;
	
	  private String descD;

	public Esc(String descName, String descD) {
		super();
		this.descName = descName;
		this.descD = descD;
	}

	public String getDescName() {
		return descName;
	}

	public void setDescName(String descName) {
		this.descName = descName;
	}

	public String getDescD() {
		return descD;
	}

	public void setDescD(String descD) {
		this.descD = descD;
	}
		
}
