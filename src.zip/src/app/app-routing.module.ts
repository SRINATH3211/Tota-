import { MyChartComponent } from './navigations/my-chart/my-chart.component';
import { EditStudentsComponent } from './navigations/students/edit-students/edit-students.component';
import { ViewStudentsComponent } from './navigations/students/view-students/view-students.component';
import { StudDashboardComponent } from './navigations/stud-dashboard/stud-dashboard.component';
import { AddStudentsComponent } from './navigations/students/add-students/add-students.component';
import { SlideshowComponent } from './navigations/slideshow/slideshow.component';
import { RecordsComponent } from './navigations/records/records.component';

import { OperationsNewsComponent } from './navigations/operations-news/operations-news.component';
import { OperationsResearchComponent } from './navigations/operations-research/operations-research.component';
import { KnowledgeDevelopmentComponent } from './navigations/knowledge-development/knowledge-development.component';
import { TeamCollaborationComponent } from './navigations/team-collaboration/team-collaboration.component';
import { IndividualLearningComponent } from './navigations/individual-learning/individual-learning.component';
import { PgOperationsComponent } from './navigations/pg-operations/pg-operations.component';
import { FacultyOperationsComponent } from './navigations/faculty-operations/faculty-operations.component';
import { DigitalClassroomComponent } from './navigations/digital-classroom/digital-classroom.component';
import { ScholasticHomeComponent } from './navigations/scholastic-home/scholastic-home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './navigations/search/search.component';
import { QuesnaireeComponent } from './navigations/quesnairee/quesnairee.component';


const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([
    { path: '', component: SlideshowComponent },
    { path: 'scholastic', component: ScholasticHomeComponent },
    { path: 'digital', component: DigitalClassroomComponent },
    { path: 'faculty', component: FacultyOperationsComponent },
    { path: 'parent', component: PgOperationsComponent },
    { path: 'individual', component: IndividualLearningComponent },
    { path: 'team', component: TeamCollaborationComponent },
    { path: 'knowledge', component: KnowledgeDevelopmentComponent },
    { path: 'research', component: OperationsResearchComponent },
    { path: 'news', component: OperationsNewsComponent },
    { path: 'records', component: RecordsComponent },
    { path: 'dash', component: StudDashboardComponent },
    { path: 'addstudent', component: AddStudentsComponent },
    { path: 'viewstudent', component: ViewStudentsComponent },
    { path: 'editstudent', component: EditStudentsComponent },
    { path: 'chart', component: MyChartComponent },
    { path: 'que', component: QuesnaireeComponent },
    { path: 'search',component:SearchComponent}
  ])],
  exports: [RouterModule]
})
export class AppRoutingModule { }
