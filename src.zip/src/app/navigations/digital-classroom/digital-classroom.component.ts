import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-digital-classroom',
  templateUrl: './digital-classroom.component.html',
  styleUrls: ['./digital-classroom.component.css']
})
export class DigitalClassroomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
