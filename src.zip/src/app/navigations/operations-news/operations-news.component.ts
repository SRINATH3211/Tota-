import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operations-news',
  templateUrl: './operations-news.component.html',
  styleUrls: ['./operations-news.component.css']
})
export class OperationsNewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
