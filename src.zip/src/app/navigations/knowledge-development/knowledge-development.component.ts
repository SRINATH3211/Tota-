import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-knowledge-development',
  templateUrl: './knowledge-development.component.html',
  styleUrls: ['./knowledge-development.component.css']
})
export class KnowledgeDevelopmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
