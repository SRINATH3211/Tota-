import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individual-learning',
  templateUrl: './individual-learning.component.html',
  styleUrls: ['./individual-learning.component.css']
})
export class IndividualLearningComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
