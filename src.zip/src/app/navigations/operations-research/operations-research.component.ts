import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operations-research',
  templateUrl: './operations-research.component.html',
  styleUrls: ['./operations-research.component.css']
})
export class OperationsResearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
