import { Component, OnInit } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
// import { error } from 'console';
import { nextTick } from 'process';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

import { AppService } from 'src/app/app.service';
import { Quesnaire } from 'src/app/Quesnaire';
// import { Quesnair, Quesnaire } from 'src/app/Quesnaire';
@Component({
  selector: 'app-faculty-operations',
  templateUrl: './faculty-operations.component.html',
  styleUrls: ['./faculty-operations.component.css']
})
export class FacultyOperationsComponent implements OnInit {

  constructor(public datah:AppService) { }

  quedatas:any;
   
  quesn :Observable<Quesnaire[]>;

  ngOnInit(): void {

  //  this.datah.Getque().subscribe((data)=>{this.quedatas=data})

  }

}
