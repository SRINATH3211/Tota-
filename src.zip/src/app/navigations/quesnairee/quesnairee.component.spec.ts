import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuesnaireeComponent } from './quesnairee.component';

describe('QuesnaireeComponent', () => {
  let component: QuesnaireeComponent;
  let fixture: ComponentFixture<QuesnaireeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuesnaireeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuesnaireeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
