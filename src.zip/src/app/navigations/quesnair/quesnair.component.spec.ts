import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuesnairComponent } from './quesnair.component';

describe('QuesnairComponent', () => {
  let component: QuesnairComponent;
  let fixture: ComponentFixture<QuesnairComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuesnairComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuesnairComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
