import { Component, OnInit } from '@angular/core';

import { AppService } from 'src/app/app.service';
import { Quesnaire } from 'src/app/Quesnaire';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-quesnair',
  templateUrl: './quesnair.component.html',
  styleUrls: ['./quesnair.component.css']
})
export class QuesComponent implements OnInit {
  quesnaire: Quesnaire =new  Quesnaire();
  submitted = false;

  constructor(  private queService:AppService) { }

  
 newQuesnaire():void{
   this.submitted=false;
   this.quesnaire=new Quesnaire();
 }
 save(){
  this.queService.createQuesnaire(this.quesnaire)
   .subscribe(data=>console.log(data));
   this.quesnaire=new Quesnaire();
 }
 
onSubmit() {
  this.submitted = true;
  this.save();    
}
ngOnInit(): void {
  // this.datah.Getque().subscribe((data)=>{this.quedatas=data})
}

}
