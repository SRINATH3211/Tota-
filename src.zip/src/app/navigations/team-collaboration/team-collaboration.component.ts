import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team-collaboration',
  templateUrl: './team-collaboration.component.html',
  styleUrls: ['./team-collaboration.component.css']
})
export class TeamCollaborationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
