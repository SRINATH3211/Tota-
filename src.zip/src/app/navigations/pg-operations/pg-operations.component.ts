import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pg-operations',
  templateUrl: './pg-operations.component.html',
  styleUrls: ['./pg-operations.component.css']
})
export class PgOperationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
