import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stud-dashboard',
  templateUrl: './stud-dashboard.component.html',
  styleUrls: ['./stud-dashboard.component.css']
})
export class StudDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
