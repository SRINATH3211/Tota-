export class Student{
    id : number;
    firstname : string;
    lastname : string;
    age : number;
    gender : string; 
}