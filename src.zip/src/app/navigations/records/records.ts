export interface IRecord{
    Firstname:string,
    Lastname:string,
    Age:number,
    Gender:string
}