import { Component, OnInit } from '@angular/core';
import { Quesnaire } from 'src/app/Quesnaire';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { Observable } from 'rxjs';
import { QuesnaireeComponent } from '../quesnairee/quesnairee.component';
import { Esc } from 'src/app/Esc';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  
  submitted = false;

  queArr:any=[];
  Quesnaire:Quesnaire[]=[];
  quename:string;
  esc = new Esc();  
  constructor(public datah:AppService) { }

  quedatas:any;
   
  quesn :Observable<Quesnaire[]>;
  ngOnInit(): void {

//   
  // this.datah.Getque(this.quename).subscribe((data)=>{this.quedatas=data});
  this.datah.Getque().subscribe((data)=>{this.quedatas=data});
  }
  search(){
      this.quedatas=this.quedatas.filter(res=>{
        return res.quename.toLocaleLowerCase().match(this.quename.toLocaleLowerCase());
      });
  }
  onSelect(event){
      let index= this.queArr.indexOf(event.target.value);
      if(index==-1){
        
        
        this.queArr.push(event.target.value);
        this.esc.descName =this.queArr[0].toString();
        this.esc.descD=this.queArr[1].toString();
        this.datah.done(this.esc).subscribe(data=>console.log(data));
      
      }else{
        this.queArr.splice(index,1);
      }
      
      console.log(this.queArr);
      console.log(this.datah);
  }
  newEsc():void{
    this.submitted=false;
    this.esc=new Esc();
  }
  save(){
   this.datah.done(this.queArr)
    .subscribe(data=>console.log(data));
    this.queArr=new Esc();
  }
  
 onSubmit() {
   this.submitted = true;
   this.save();    
 }
//  getEscData(){
//    this.datah.getData().subscribe(res=>{
//      this.queArr=res;})
//  }
//     insertData(){
//       this.datah.insertData(this.esc).subscribe(res=>{
//         this.getEscData();});
//     }
  
}