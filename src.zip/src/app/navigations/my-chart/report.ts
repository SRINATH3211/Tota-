export class Report{
    id : number;
    name : string;
    branch : string;
    nominated : string;
    participated : string;
    qualified : string;
    winners : string 
}