export class Esc{
    descName:any;
    descD:any;
}   