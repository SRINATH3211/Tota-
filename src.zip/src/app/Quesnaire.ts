
export class Quesnaire {
    queid: number;
    quename: string;
    quedesc: string;
    createdby: string;
    updateby: string;
    deleteby: string;
    avtive: string;
}

